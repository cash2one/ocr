webpackJsonp([1,0],[
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(1);


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	if (false) {
	  require('../../index.html');
	}

	__webpack_require__(2);

	var delay = 200;
	var uri = '/';

	var scoreStatus = {
	  0: 'locked',
	  1: 'live',
	  2: 'score'
	};

	var getConfig = function getConfig(cb) {
	  return $.ajax({
	    url: '/static/json/config.json',
	    type: 'get',
	    contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
	    dataType: 'json',
	    success: function success(data) {
	      return cb(data);
	    }
	  });
	};
	getConfig(function (config) {
	  var _config;

	  return _config = config, delay = _config.delay, uri = _config.uri, _config;
	});

	var isMobile = function isMobile() {
	  return !!window.navigator.userAgent.match(/AppleWebKit.*Mobile.*/);
	};

	$(function () {
	  if (isMobile()) {
	    $('body').on('touchstart', function () {
	      $('nav').css({
	        'background-color': 'rgba(18,22,31,' + Math.min($(window).scrollTop(), delay) / 100 + ')'
	      });
	    });
	  } else {
	    $(window).on('scroll', function () {
	      $('nav').css({
	        'background-color': 'rgba(18,22,31,' + Math.min($(window).scrollTop(), delay) / 100 + ')'
	      });
	    });
	  }

	  $('.btn-more-link').attr('href', isMobile() ? 'http://m.news.baidu.com/news?ssid=0&from=0&bd_page_type=1&uid=&pu=sz%401320_480%2cosname%40iphone&ext=nt&fr=bdk2#/search/%E7%99%BE%E5%BA%A6%E5%A4%A7%E8%84%91%20%E6%9C%80%E5%BC%BA%E5%A4%A7%E8%84%91?_k=5z4ajs' : 'http://news.baidu.com/ns?cl=2&rn=20&tn=news&word=%E7%99%BE%E5%BA%A6%E5%A4%A7%E8%84%91%20%E6%9C%80%E5%BC%BA%E5%A4%A7%E8%84%91');

	  $('.btn-more-viewer').on('click', function (e) {
	    return $(e.currentTarget).parent('[data-target]').find('img:eq(0)').trigger('click');
	  });

	  var getData = function getData(item, cb) {
	    return $.ajax({
	      url: uri + 'static/json/' + item + '.json',
	      type: 'get',
	      contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
	      dataType: 'json',
	      success: function success(data) {
	        return cb(data);
	      }
	    });
	  };

	  getData('news', function (data) {
	    $('[data-target=news]')[0].innerHTML = [].reduce.call(data, function (prev, next) {
	      var html = next.active ? '<li class="active">\n            <a href="' + next.link + '" target="_blank">\n              <figure>\n                <img src="' + next.poster + '">\n              </figure>\n              <h3>' + next.title + '</h3>\n            </a>\n          </li>' : '<li>\n            <a href="' + next.link + '" target="_blank">\n              <h3>\n                <small>' + next.source + '</small>\n                ' + next.title + '\n              </h3>\n              <p>' + next.content + '</p>\n            </a>\n          </li>';
	      return next.active ? html + prev : prev + html;
	    }, '');
	  });

	  getData('video', function (data) {
	    var player = $('[data-target=video]').find('.video iframe')[0];
	    var slider = $('[data-target=video]').find('ul')[0];
	    var list = $('[data-target=video]').find('.list')[0];
	    slider.innerHTML = [].reduce.call(data, function (prev, next) {
	      if (next.active) player.src = next.iqiyi;
	      return prev + '<li data-iqiyi="' + next.iqiyi + '">\n        <figure>\n          <img src="' + next.shortcut + '">\n        </figure>\n      </li>';
	    }, '');
	    UIkit.slideset($('[data-target=video]').find('.list')[0], {
	      default: 3,
	      small: 3,
	      medium: 4,
	      large: 5
	    });
	    slider.onclick = function (e) {
	      if (e.target && e.target.nodeName.toLowerCase() === 'img') {
	        var li = e.target.parentElement.parentElement;
	        [].forEach.call(slider.querySelectorAll('li'), function (i) {
	          return i.classList.remove('on-play');
	        });
	        li.classList.add('on-play');
	        player.src = li.dataset.iqiyi || player.src;
	      }
	    };
	  });

	  getData('gallery', function (data) {
	    var gallery = $('[data-target=gallery]').find('.gallery')[0];
	    var slider = $('[data-target=gallery]').find('ul')[0];
	    gallery.innerHTML = '<figure><img src="' + data.shift().url + '"></figure>';
	    slider.innerHTML = [].reduce.call(data, function (prev, next) {
	      return prev + '<li>\n        <figure>\n          <img src="' + next.url + '">\n        </figure>\n      </li>';
	    }, '');
	    UIkit.slideset($('[data-target=gallery]').find('.list')[0], {
	      default: 3,
	      small: 3,
	      medium: 4,
	      large: 5
	    });
	    $('.gallery__wrapper').viewer({
	      toolbar: 2,
	      movable: false,
	      scalable: false,
	      zoomable: false
	    });
	  });

	  getData('moment', function (data) {
	    var moment = $('.moment figure');
	    var inMoment = data.splice(0, moment.length);
	    [].forEach.call(moment, function (img, idx) {
	      $(img).html('<img src="' + inMoment[idx].url + '" class="' + (inMoment[idx].wide && (idx === 1 || idx === 3) ? 'wide' : '') + '">');
	    });
	    [].forEach.call(data, function (img, index) {
	      $('.moment').append('<img style="display:none" src="' + img.url + '">');
	    });
	    $('.moment').viewer({
	      toolbar: 2,
	      movable: false,
	      scalable: false,
	      zoomable: false
	    });
	  });

	  getData('score', function (data) {
	    var curTime = new Date().valueOf();
	    var score = $('[data-target=score]').find('ul')[0];
	    score.innerHTML = [].reduce.call(data, function (prev, next, idx) {
	      var ref = 0;
	      if (curTime > new Date(data[idx].begin_time).valueOf()) ref += 1;
	      if (curTime > new Date(data[idx].end_time).valueOf()) ref += 1;
	      return prev + '<li class="' + (ref === 1 ? 'live' : '') + '">\n        <figure>\n          <img src="/static/images/score/b-' + (idx + 1) + '-' + scoreStatus[ref] + '.png">\n        </figure>';
	    }, '');
	  });
	});

/***/ },
/* 2 */
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }
]);